package com.example.apmd_android;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class textspeech extends AppCompatActivity implements JsonResponse {

    private SpeechRecognizer speechRecognizer;
    private Intent speechRecognizerIntent;
    private TextView tvResult;
    private Button b1;
    TextView t1,t2;
    private SharedPreferences sh;
    private String recognizedText; // Variable to store the recognized text

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_textspeech);

        TextView tvQuestion = findViewById(R.id.tvQuestion);
        Button btnSpeechToText = findViewById(R.id.btnSpeechToText);
        tvResult = findViewById(R.id.tvResult);
        b1 = findViewById(R.id.btsend);
//        b1.setVisibility(View.GONE);
        t1 = findViewById(R.id.re);
        t2=(TextView) findViewById(R.id.textView7);


        sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        // Get the question from the intent
        String question = getIntent().getStringExtra("question");
        tvQuestion.setText(question);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JsonReq JR = new JsonReq();
                JR.json_response = textspeech.this;
                String text = tvResult.getText().toString();
                String q = "/textspeech?tvResult=" + text + "&log_id=" + sh.getString("logid", "")+ "&qn_id=" + View_questions.qid;
                q = q.replace(" ", "%20");
                JR.execute(q);
            }
        });

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");

        btnSpeechToText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermission();
            }
        });

        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
            }

            @Override
            public void onBeginningOfSpeech() {
            }

            @Override
            public void onRmsChanged(float rmsdB) {
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
            }

            @Override
            public void onEndOfSpeech() {
            }

            @Override
            public void onError(int error) {
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && matches.size() > 0) {
                    recognizedText = matches.get(0);
                    tvResult.setText(recognizedText);
//                    b1.setVisibility(View.VISIBLE);

                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
            }
        });
    }

    private void checkPermission() {
        int permission = ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO);
        if (permission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        } else {
            startSpeechToText();
        }
    }

    private void startSpeechToText() {
        speechRecognizer.startListening(speechRecognizerIntent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startSpeechToText();
        }
    }

    @Override
    public void response(JSONObject jo) {

//        try {
//            String status = jo.getString("status");
//            Log.d("pearl", status);
//
////
////                String output = jo.getString("out");
////                t1.setText(jo.getString("out"));
////                Toast.makeText(getApplicationContext(), "Pedicted Out" + output, Toast.LENGTH_LONG).show();
////
//
//            if (status.equalsIgnoreCase("success")) {
//                JSONArray ja1 = jo.getJSONArray("out");
//                t1.setText(jo.getString("out"));
//
////                t1.setText(ja1.getJSONObject(0).getString("out"));
//
//                Toast.makeText(getApplicationContext(), "SSSSSSSSSSSSSSSSSSSSSSSSSs ", Toast.LENGTH_LONG).show();
//
//                Intent intent = new Intent(getApplicationContext(),textspeech.class);
//                intent.putExtra("recognizedText", recognizedText);
//                startActivity(intent);
//            } else {
//                Toast.makeText(getApplicationContext(), "Login failed..! Please enter correct username or password ", Toast.LENGTH_LONG).show();
//
//                Intent intent = new Intent(getApplicationContext(), textspeech.class);
//                intent.putExtra("recognizedText", recognizedText);
//                startActivity(intent);
//            }


        try {

            String status = jo.getString("status");
            String output=jo.getString("out");
            t2.setText(jo.getString("out"));
            Toast.makeText(getApplicationContext(),"Pedicted Out"+output, Toast.LENGTH_LONG).show();

            Log.d("result", status);

            if (status.equalsIgnoreCase("success")) {
                Toast.makeText(getApplicationContext(), "Result Found....\n Successfully Updated", Toast.LENGTH_LONG).show();
//		                JSONArray ja = (JSONArray) jo.getJSONArray("data");
//		                labels = ja.getJSONObject(0).getString("label");
//		                pre = ja.getJSONObject(0).getString("precatuions");



                //startActivity(new Intent(getApplicationContext(),Viewmodeldetails.class));
//                startActivity(new Intent(getApplicationContext(),textspeech.class));

            }
            else if (status.equalsIgnoreCase("failed")) {

                Toast.makeText(getApplicationContext(),"Image Not Found", Toast.LENGTH_LONG).show();
//                startActivity(new Intent(getApplicationContext(),Student_reading_exam.class));
            }


            else if (status.equalsIgnoreCase("duplicate")) {
//					Toast.makeText(getApplicationContext(),"Interested Place Added Failed", Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(), "Already Added....",
                        Toast.LENGTH_LONG).show();
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"Response Exc : " + e.toString(), Toast.LENGTH_LONG).show();
        }
    }



    // UPDATED!
    public String getPaths(Uri uri) {
        String[] projection = { MediaStore.Video.Media.DATA };
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);
        if (cursor != null) {
            // HERE YOU WILL GET A NULLPOINTER IF CURSOR IS NULL
            // THIS CAN BE, IF YOU USED OI FILE MANAGER FOR PICKING THE MEDIA
            int column_index = cursor
                    .getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } else
            return null;
    }
}


//} catch (Exception e) {
//            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
//        }
//    }

